package com.sheroz.quizcalculator;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class QuizActivity extends AppCompatActivity {

    TextView tv;
    Button nextQuestionBtn, quitBtn;
    RadioGroup answersgrp;
    RadioButton rb1,rb2,rb3,rb4;

    String[] questions = {
            "HTML is what type of language ?",
            "HTML uses",
            "The year in which HTML was first proposed ____.",
            "Fundamental HTML Block is known as ____.",
            "Apart from <b> tag, what other tag makes text bold?",
            "What is the full form of HTML?",
            "Who is Known as the father of World Wide Web (WWW)?",
            "What should be the first tag in any HTML document?",
            "How can you make a bulleted list with numbers?",
            "What tag is used to display a picture in a HTML page?"
    };

    String[] answers = {"Markup Language","Fixed tags defined by the language","1990","HTML Tag","<strong>","HyperText Markup Language","Tim Berners-Lee","<html>","<ol>","img"};
    String[] opt = {
            "Scripting Language","Markup Language","Programming Language","Network Protocol",
            "User defined tags","Pre-specified tags","Fixed tags defined by the language","Tags only for linking",
            "1990","1980","2000","1995",
            "HTML Body","HTML Tag","HTML Attribute","HTML Element",
            "<fat>","<strong>","<black>","<emp>",
            "HyperText Markup Language","HyperTeach Markup Language","HyperTech Markup Language","none of these",
            "Robert Cailliau","Tim Thompson","Charles Darwin","Tim Berners-Lee",
            "<head>","<title>","<html>","<document>",
            "<dl>","<ol>","<list>","<ul>",
            "picture","image","img","src"
    };

    int flag=0;
    public static int marks=0,correct=0,wrong=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        final TextView score = (TextView)findViewById(R.id.totalScoreTv);
        TextView textView=(TextView)findViewById(R.id.DispName);
        Intent intent = getIntent();
        String name= intent.getStringExtra("myname");

        if (name.trim().equals(""))
            textView.setText("Hello User");
        else
            textView.setText("Hello " + name);

        nextQuestionBtn=(Button)findViewById(R.id.nextQuestionBtn);
        quitBtn =(Button)findViewById(R.id.quitBtn);
        tv=(TextView) findViewById(R.id.tvque);

        answersgrp =(RadioGroup)findViewById(R.id.answersgrp);
        rb1=(RadioButton)findViewById(R.id.radioButton);
        rb2=(RadioButton)findViewById(R.id.radioButton2);
        rb3=(RadioButton)findViewById(R.id.radioButton3);
        rb4=(RadioButton)findViewById(R.id.radioButton4);
        tv.setText(questions[flag]);
        rb1.setText(opt[0]);
        rb2.setText(opt[1]);
        rb3.setText(opt[2]);
        rb4.setText(opt[3]);
        nextQuestionBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(answersgrp.getCheckedRadioButtonId()==-1)
                {
                    Toast.makeText(getApplicationContext(), "Please select one choice", Toast.LENGTH_SHORT).show();
                    return;
                }
                RadioButton uans = (RadioButton) findViewById(answersgrp.getCheckedRadioButtonId());
                String ansText = uans.getText().toString();
                if(ansText.equals(answers[flag])) {
                    correct++;
                    Toast.makeText(getApplicationContext(), "Correct", Toast.LENGTH_SHORT).show();
                }
                else {
                    wrong++;
                    Toast.makeText(getApplicationContext(), "Wrong", Toast.LENGTH_SHORT).show();
                }

                flag++;

                if (score != null)
                    score.setText(""+correct);

                if(flag<questions.length)
                {
                    tv.setText(questions[flag]);
                    rb1.setText(opt[flag*4]);
                    rb2.setText(opt[flag*4 +1]);
                    rb3.setText(opt[flag*4 +2]);
                    rb4.setText(opt[flag*4 +3]);
                }
                else
                {
                    marks=correct;
                    Intent in = new Intent(getApplicationContext(),ResultActivity.class);
                    startActivity(in);
                }
                answersgrp.clearCheck();
            }
        });

        quitBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent=new Intent(getApplicationContext(),ResultActivity.class);
                startActivity(intent);
            }
        });
    }

}